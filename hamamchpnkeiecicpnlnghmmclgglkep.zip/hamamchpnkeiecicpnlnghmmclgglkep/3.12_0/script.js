var invoices = 0;
var loading = false;
var button = document.createElement("button");
button.innerHTML = "Tải hóa đơn";
button.id = "bulKbutton";
button.style.cssText = 'position: fixed; top: 23%; right: 110px; transform: translateY(-30%); height: 50px; font-size: 18px; padding: 8px 20px; background-color: #4CAF50; color: white; border: 2px solid #4CAF50; border-radius: 4px; cursor: pointer;';

document.body.appendChild(button);

button.addEventListener("click", function() {
  var x = 0
  let bool = document.querySelector('main > div > div > div > div > div ').nextSibling.nextSibling.querySelectorAll('div[role=tabpanel]')[0].className.includes('inactive')
  if(bool)
    x = 1
  Download(x);
});

async function Download(x) {
  const button = document.getElementsByClassName('ant-col');
  let num = button[button.length - 7].innerText;
  const parts = num.split('/');
  const extractedNumber = parts[1].trim();

  for (let i = 1; i <= extractedNumber ; i++) {
    invoices = document.getElementsByClassName('ant-table-tbody')[x].querySelectorAll('tr');
    console.log(invoices)
    for (let i = 0; i < invoices.length; i++) {
        invoices[i].click()
        await delay(100);
        button[button.length - 1].querySelector('button').click()

        loading = document.querySelector('.ant-spin-text').checkVisibility();
        while(loading){
          await delay(1000);
          if(!loading)
          {
            await delay(1000);
            break;
          }
          loading = document.querySelector('.ant-spin-text').checkVisibility();
        }
    }
      button[button.length - 6].querySelector('button').click()
      await delay(5000)
    } 
}

async function delay(time) {
  return await new Promise(resolve => setTimeout(resolve, time));
};
 