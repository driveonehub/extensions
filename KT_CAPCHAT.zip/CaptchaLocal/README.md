# KT_AI Captcha

Thiết kế bởi **LỀNH SẦU · 0908900053**

Tiện ích Chrome / Edge / Cốc Cốc tự đọc captcha dạng ảnh chữ/số trên **mọi trang web**.
Mô hình **ddddocr** (MIT) chạy ngay trong trình duyệt bằng **onnxruntime-web** (MIT).
Không cần kích hoạt, không gửi ảnh hay dữ liệu ra ngoài.

## Cài đặt

1. Mở `chrome://extensions` (Edge: `edge://extensions`, Cốc Cốc: `coccoc://extensions`).
2. Bật **Chế độ dành cho nhà phát triển** (Developer mode).
3. Bấm **Tải tiện ích đã giải nén** (Load unpacked) → chọn thư mục `CaptchaLocal`.
4. Mở trang có captcha. Ô captcha sẽ tự được điền và viền xanh.

## Dùng

- Popup: bật/tắt chung, **bật/tắt riêng trang đang mở**, chọn loại ký tự, ép HOA/thường, **Đọc lại**.
- Nếu bạn tự gõ vào ô captcha, tiện ích không ghi đè (trừ khi bấm **Đọc lại**).
- Khi ảnh captcha đổi (bấm làm mới), tiện ích tự đọc lại.
- Ô OTP / SMS không bao giờ bị tự điền. Trên trang lạ, ô "mã xác nhận" chỉ được điền khi ảnh bên cạnh
  trông giống captcha. Nếu trang có captcha mà không tự đọc, bấm **Đọc lại captcha trên trang này**.
- ddddocr hay nhầm hoa/thường ở `K/k`, `H/h`, `X/x`. Nếu trang không phân biệt hoa/thường, chọn **HOA**.
- Không giải được reCAPTCHA / hCaptcha (chọn hình) – chỉ captcha dạng ảnh chữ/số.

## Cấu trúc

| File | Vai trò |
|---|---|
| `config.js` | Tên tác giả, số điện thoại, địa chỉ máy chủ bản quyền + cập nhật (`apiUrl`), số ngày dùng thử |
| `content.js` | Tìm ô nhập + ảnh captcha (img / svg / canvas), điền kết quả |
| `background.js` | Điều phối, tạo trang ẩn chạy mô hình, kiểm tra cập nhật |
| `offscreen.js` | Tiền xử lý ảnh (cao 64px, ảnh xám) + chạy mô hình + giải mã CTC |
| `popup.html/js` | Giao diện |
| `models/ddddocr_old.onnx` | Mô hình `common_old.onnx` của ddddocr 1.4.11, thêm đầu ra logits (`387`) để giới hạn ký tự |
| `models/charset.json` | Bảng ký tự của mô hình |
| `lib/` | onnxruntime-web 1.17.3 (bản wasm SIMD, 1 luồng) |
