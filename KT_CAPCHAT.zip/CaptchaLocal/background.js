// Service worker: điều phối giữa trang web (content.js) và bộ đọc AI (offscreen.html),
// quản lý bản quyền (dùng thử / kích hoạt) và kiểm tra cập nhật.
// Máy chủ duy nhất được gọi là CONFIG.apiUrl (Google Apps Script), chỉ gửi ID máy + ngày cài + phiên bản.
// Ảnh captcha không bao giờ rời khỏi máy.

importScripts("config.js");
const CONFIG = self.CAPTCHA_LOCAL_CONFIG;
const OFFSCREEN_URL = "offscreen.html";
const DEFAULTS = { enabled: true, charset: "alnum", letterCase: "keep" };
const DAY = 86400000;
// Trang dùng captcha toàn chữ IN HOA (Tổng cục Thuế: thuedientu, hoadondientu, canhan...)
const UPPERCASE_SITES = /(^|\.)gdt\.gov\.vn$/i;
let creating = null;

chrome.runtime.onInstalled.addListener(async () => {
  const cur = await chrome.storage.sync.get(DEFAULTS);
  await chrome.storage.sync.set(cur);
  setupUpdateAlarm();
  checkUpdate().catch(() => {});
  license().catch(() => {});
  injectIntoOpenTabs();
});

// Sau khi cài / cập nhật / tải lại tiện ích, các tab đang mở chưa có content script -> chèn vào luôn.
async function injectIntoOpenTabs() {
  const tabs = await chrome.tabs.query({ url: ["http://*/*", "https://*/*"] });
  await Promise.all(tabs.map((t) =>
    chrome.scripting.executeScript({ target: { tabId: t.id, allFrames: true }, files: ["content.js"] }).catch(() => {})
  ));
}
chrome.runtime.onStartup.addListener(() => {
  setupUpdateAlarm();
  checkUpdate().catch(() => {});
  license().catch(() => {});
});

function errText(e) { return String(e && e.message ? e.message : e); }

function apiUrl(params) {
  const u = new URL(CONFIG.apiUrl);
  for (const [k, v] of Object.entries(params)) u.searchParams.set(k, v);
  u.searchParams.set("t", Date.now());
  return u.toString();
}

async function apiGet(params) {
  if (!CONFIG.apiUrl) throw new Error("Chưa cấu hình máy chủ (config.js → apiUrl)");
  const res = await fetch(apiUrl(params), { cache: "no-store", credentials: "omit" });
  if (!res.ok) throw new Error("Máy chủ lỗi (HTTP " + res.status + ")");
  let j;
  try { j = await res.json(); } catch (e) { throw new Error("Máy chủ trả về dữ liệu lạ - kiểm tra lại quyền truy cập Web App"); }
  if (j.ok === false) throw new Error(j.error || "Máy chủ báo lỗi");
  return j;
}

// ------------------------------------------------------------ Bản quyền
// ID máy được lưu ở storage.sync (theo tài khoản Chrome) + local, nên gỡ/cài lại không đổi ID
// và không được dùng thử lại từ đầu (khi Chrome có đăng nhập đồng bộ).
let identityP = null;
function identity() {
  return identityP || (identityP = (async () => {
    const keys = ["deviceId", "installAt"];
    const [sy, lo] = await Promise.all([chrome.storage.sync.get(keys).catch(() => ({})), chrome.storage.local.get(keys)]);
    const deviceId = sy.deviceId || lo.deviceId || newId();
    const installAt = Math.min(sy.installAt || Infinity, lo.installAt || Infinity, Date.now());
    if (sy.deviceId !== deviceId || sy.installAt !== installAt) await chrome.storage.sync.set({ deviceId, installAt }).catch(() => {});
    if (lo.deviceId !== deviceId || lo.installAt !== installAt) await chrome.storage.local.set({ deviceId, installAt });
    return { deviceId, installAt };
  })().catch((e) => { identityP = null; throw e; }));
}

function newId() {
  const A = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // bỏ ký tự dễ nhầm O/0, I/1
  const b = crypto.getRandomValues(new Uint8Array(12));
  const s = Array.from(b, (x) => A[x % A.length]).join("");
  return "KT-" + s.slice(0, 4) + "-" + s.slice(4, 8) + "-" + s.slice(8, 12);
}

// ---- Chữ ký số: chỉ tin kết quả do máy chủ ký (không giả được máy chủ / không sửa được dữ liệu lưu trên máy)
let pubKeyP = null;
function pubKey() {
  return pubKeyP || (pubKeyP = crypto.subtle.importKey(
    "spki", Uint8Array.from(atob(CONFIG.publicKey), (c) => c.charCodeAt(0)),
    { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["verify"]));
}
const verified = new Map(); // sig -> true/false (đỡ phải kiểm tra lại)
async function verifyRec(rec) {
  if (!rec || typeof rec.sig !== "string") return false;
  const data = [rec.id, rec.status, rec.expires, rec.trialEnds, rec.now].join("|");
  const k = rec.sig + "#" + data;
  if (verified.has(k)) return verified.get(k);
  let ok = false;
  try {
    const sig = Uint8Array.from(atob(rec.sig), (c) => c.charCodeAt(0));
    ok = await crypto.subtle.verify("RSASSA-PKCS1-v1_5", await pubKey(), sig, new TextEncoder().encode(data));
  } catch (e) { ok = false; }
  verified.set(k, ok);
  return ok;
}

// Tính trạng thái từ kết quả máy chủ gần nhất (rec, đã kiểm tra chữ ký) hoặc từ ngày cài nếu chưa có.
function evaluate(rec, ident, now) {
  if (rec && rec.id === ident.deviceId) {
    const t = Math.max(now, rec.now || 0);
    if (rec.status === "locked") return { status: "locked", until: 0, wasLicensed: rec.expires > 0 };
    if (rec.expires > t) {
      if (CONFIG.apiUrl && t - rec.now > CONFIG.offlineGraceDays * DAY) return { status: "offline", until: rec.expires };
      return { status: "licensed", until: rec.expires };
    }
    if (rec.trialEnds > t) return { status: "trial", until: rec.trialEnds, pending: !!rec.pending };
    return { status: "expired", until: 0, wasLicensed: rec.expires > 0, pending: !!rec.pending };
  }
  const trialEnds = ident.installAt + CONFIG.trialDays * DAY;
  return trialEnds > now ? { status: "trial", until: trialEnds } : { status: "expired", until: 0 };
}

function licenseMessage(lic) {
  if (lic.status === "locked") return "ID này đã bị khóa. Vui lòng liên hệ " + CONFIG.phone + " (Zalo).";
  if (lic.status === "offline") return "Không kết nối được máy chủ bản quyền đã " + CONFIG.offlineGraceDays + " ngày. Kiểm tra mạng rồi bấm \"Kiểm tra lại\".";
  const call = "Vui lòng liên hệ " + CONFIG.phone + " (Zalo), gửi ID: " + lic.id + " để nhận key kích hoạt.";
  if (lic.wasLicensed) return "Đã hết hạn sử dụng. " + call;
  return "Đã hết hạn dùng thử " + CONFIG.trialDays + " ngày. " + call;
}

async function saveServerRec(j, ident) {
  const rec = {
    id: String(j.id), status: String(j.status), expires: Number(j.expires) || 0, trialEnds: Number(j.trialEnds) || 0,
    now: Number(j.now) || 0, sig: String(j.sig || ""), pending: !!j.pending, checkedAt: Date.now()
  };
  if (rec.id !== ident.deviceId || !(await verifyRec(rec))) throw new Error("Phản hồi máy chủ không hợp lệ (sai chữ ký)");
  await chrome.storage.local.set({ licRec: rec });
  return rec;
}

let refreshing = null;
let lastAttempt = 0;
function refreshLicense() {
  if (!refreshing) {
    lastAttempt = Date.now();
    refreshing = (async () => {
      const ident = await identity();
      const j = await apiGet({ action: "license", id: ident.deviceId, installAt: ident.installAt, v: chrome.runtime.getManifest().version });
      return saveServerRec(j, ident);
    })().finally(() => (refreshing = null));
  }
  return refreshing;
}

// Khách nhập key -> máy chủ kiểm tra key đúng với ID máy này
async function activate(key) {
  const ident = await identity();
  const j = await apiGet({ action: "activate", id: ident.deviceId, key: String(key || "").trim(), v: chrome.runtime.getManifest().version });
  await saveServerRec(j, ident);
  return license();
}

// Trả về trạng thái bản quyền hiện tại; force = hỏi lại máy chủ ngay.
async function license({ force = false } = {}) {
  const ident = await identity();
  let { licRec: rec, maxNow = 0 } = await chrome.storage.local.get(["licRec", "maxNow"]);
  if (rec && !(await verifyRec(rec))) rec = null; // dữ liệu bị sửa tay -> bỏ
  // Không cho chỉnh lùi đồng hồ máy tính để kéo dài thời hạn
  const now = Math.max(Date.now(), maxNow);
  if (now - maxNow > 60000) chrome.storage.local.set({ maxNow: now });

  let st = evaluate(rec, ident, now);
  let error = "";
  const usable = st.status === "trial" || st.status === "licensed";
  const stale = !rec || rec.id !== ident.deviceId || Date.now() - rec.checkedAt > CONFIG.checkEveryHours * 3600e3;
  // Chưa có kết quả hợp lệ từ máy chủ (mới cài, hoặc dữ liệu bị sửa) -> phải hỏi máy chủ, không tự cho dùng thử
  const noValid = !rec || rec.id !== ident.deviceId;
  if (CONFIG.apiUrl && (force || noValid || (!usable && Date.now() - lastAttempt > 15000))) {
    // Đang hết hạn: hỏi lại máy chủ ngay (tối đa 1 lần/15 giây)
    try { rec = await refreshLicense(); st = evaluate(rec, ident, now); } catch (e) { error = errText(e); }
  } else if (CONFIG.apiUrl && stale) {
    refreshLicense().then(() => license()).catch(() => {});
  }

  const lic = {
    id: ident.deviceId, status: st.status, until: st.until, wasLicensed: !!st.wasLicensed, pending: !!st.pending,
    usable: st.status === "trial" || st.status === "licensed",
    daysLeft: st.until > now ? Math.ceil((st.until - now) / DAY) : 0,
    trialDays: CONFIG.trialDays, checkedAt: rec && rec.id === ident.deviceId ? rec.checkedAt : 0,
    server: !!CONFIG.apiUrl, error
  };
  lic.message = lic.usable ? "" : licenseMessage(lic);
  const { lic: old } = await chrome.storage.local.get("lic");
  if (JSON.stringify(old) !== JSON.stringify(lic)) await chrome.storage.local.set({ lic });
  refreshBadge();
  return lic;
}

async function refreshBadge() {
  const { lic, update } = await chrome.storage.local.get(["lic", "update"]);
  if (lic && !lic.usable) {
    chrome.action.setBadgeText({ text: "!" });
    chrome.action.setBadgeBackgroundColor({ color: "#dc2626" });
    chrome.action.setTitle({ title: "KT_AI Captcha - hết hạn, liên hệ " + CONFIG.phone });
  } else {
    chrome.action.setBadgeText({ text: update && update.available ? "NEW" : "" });
    chrome.action.setBadgeBackgroundColor({ color: "#f97316" });
    chrome.action.setTitle({ title: "KT_AI Captcha" });
  }
}

// ------------------------------------------------------------ Cập nhật (qua tab "CapNhat" của Google Sheet)
// Máy chủ trả về: { version: "1.3.1", download: "https://drive.google.com/uc?export=download&id=...", notes: "..." }
function cmpVer(a, b) {
  const pa = String(a).split(".").map(Number), pb = String(b).split(".").map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d) return d > 0 ? 1 : -1;
  }
  return 0;
}

function setupUpdateAlarm() {
  // Kể cả khi chưa có máy chủ: báo hết hạn dùng thử đúng lúc
  chrome.alarms.create("check-update", { periodInMinutes: Math.min(CONFIG.checkEveryHours * 60, 360) });
}
chrome.alarms.onAlarm.addListener((a) => {
  if (a.name !== "check-update") return;
  if (CONFIG.apiUrl) checkUpdate().catch(() => {});
  license().catch(() => {});
});

async function checkUpdate() {
  const info = await apiGet({ action: "version" });
  const current = chrome.runtime.getManifest().version;
  const update = {
    checkedAt: Date.now(),
    current,
    latest: String(info.version || current),
    download: String(info.download || ""),
    notes: String(info.notes || ""),
    available: cmpVer(info.version, current) > 0
  };
  await chrome.storage.local.set({ update });
  refreshBadge();
  return update;
}

async function ensureOffscreen() {
  const ctx = await chrome.runtime.getContexts({
    contextTypes: ["OFFSCREEN_DOCUMENT"],
    documentUrls: [chrome.runtime.getURL(OFFSCREEN_URL)]
  });
  if (ctx.length) return;
  if (!creating) {
    creating = chrome.offscreen
      .createDocument({
        url: OFFSCREEN_URL,
        reasons: ["WORKERS"],
        justification: "Chạy mô hình nhận dạng captcha cục bộ bằng WebAssembly"
      })
      .catch((e) => {
        if (!String(e).includes("Only a single offscreen")) throw e;
      })
      .finally(() => (creating = null));
  }
  await creating;
}

function siteOf(host) {
  // So khớp theo 2 nhãn cuối, hoặc 3 nhãn nếu là *.gov.vn / *.com.vn ...
  const p = String(host).toLowerCase().split(".");
  const n = p.length >= 3 && ["gov", "com", "edu", "net", "org"].includes(p[p.length - 2]) ? 3 : 2;
  return p.slice(-n).join(".");
}

async function fetchAsDataUrl(url) {
  const res = await fetch(url, { credentials: "include", cache: "no-store" });
  if (!res.ok) throw new Error("HTTP " + res.status);
  const blob = await res.blob();
  const buf = new Uint8Array(await blob.arrayBuffer());
  let bin = "";
  for (let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
  return "data:" + (blob.type || "image/png") + ";base64," + btoa(bin);
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.target === "offscreen") return; // tin dành cho offscreen

  if (msg.type === "CHECK_UPDATE") {
    checkUpdate()
      .then((update) => sendResponse({ ok: true, update }))
      .catch((e) => sendResponse({ ok: false, error: errText(e) }));
    return true;
  }

  if (msg.type === "LICENSE") {
    license({ force: !!msg.force })
      .then((lic) => sendResponse({ ok: true, lic }))
      .catch((e) => sendResponse({ ok: false, error: errText(e) }));
    return true;
  }

  if (msg.type === "ACTIVATE") {
    activate(msg.key)
      .then((lic) => sendResponse({ ok: true, lic }))
      .catch((e) => sendResponse({ ok: false, error: errText(e) }));
    return true;
  }

  if (msg.type === "OCR") {
    (async () => {
      const lic = await license();
      if (!lic.usable) return { ok: false, code: "LICENSE", error: lic.message };
      const settings = await chrome.storage.sync.get(DEFAULTS);
      let dataUrl = msg.dataUrl;
      if (!dataUrl && msg.url) {
        // Chỉ tải lại ảnh nếu cùng site với trang đang mở
        const pageHost = new URL(sender.url || (sender.tab && sender.tab.url) || "about:blank").hostname;
        if (siteOf(new URL(msg.url).hostname) !== siteOf(pageHost)) throw new Error("Ảnh không cùng nguồn với trang");
        dataUrl = await fetchAsDataUrl(msg.url);
      }
      await ensureOffscreen();
      const res = await chrome.runtime.sendMessage({
        target: "offscreen",
        type: "OCR",
        dataUrl,
        charset: settings.charset
      });
      if (!res || !res.ok) throw new Error((res && res.error) || "Bộ đọc không phản hồi");
      let text = res.text;
      // Chữ hoa/thường: cài riêng cho trang > cài chung > "Tự động" (trang thuế -> IN HOA, còn lại giữ như AI đọc)
      let host = "";
      try { host = new URL((sender.tab && sender.tab.url) || sender.url || "").hostname; } catch (e) {}
      const { siteCase = {} } = await chrome.storage.sync.get("siteCase");
      let mode = siteCase[host] || settings.letterCase;
      if (!siteCase[host] && mode === "keep" && UPPERCASE_SITES.test(host)) mode = "upper";
      // "Tự động": dùng kết quả đã sửa hoa/thường theo chiều cao chữ (nếu bộ đọc chắc chắn)
      if (mode === "keep" && !siteCase[host] && res.auto) text = res.auto;
      if (mode === "upper") text = text.toUpperCase();
      if (mode === "lower") text = text.toLowerCase();
      const { count = 0 } = await chrome.storage.local.get("count");
      await chrome.storage.local.set({
        count: count + 1,
        last: { text, at: Date.now(), ms: res.ms, host: sender.url ? new URL(sender.url).hostname : "" }
      });
      return { ok: true, text };
    })()
      .then(sendResponse)
      .catch((e) => sendResponse({ ok: false, error: errText(e) }));
    return true;
  }
});
