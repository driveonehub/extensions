// Bộ đọc captcha: mô hình ddddocr (common_old, MIT) chạy bằng onnxruntime-web (WebAssembly).
// Tiền xử lý giống ddddocr gốc: cao 64px, ảnh xám, chuẩn hóa (x/255 - 0.5) / 0.5, giải mã CTC.

/* global ort */
ort.env.wasm.wasmPaths = chrome.runtime.getURL("lib/");
ort.env.wasm.numThreads = 1;
ort.env.wasm.proxy = false;

const LOGITS = "387"; // đầu ra trước ArgMax, shape [T, 1, C] (đã thêm bằng tools/prep_model.py)
const CHARSETS = {
  alnum: "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ",
  digits: "0123456789",
  letters: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
};

let sessionPromise = null;
let charset = null;
const allowedCache = {};

function load() {
  if (!sessionPromise) {
    sessionPromise = (async () => {
      const [model, cs] = await Promise.all([
        fetch(chrome.runtime.getURL("models/ddddocr_old.onnx")).then((r) => r.arrayBuffer()),
        fetch(chrome.runtime.getURL("models/charset.json")).then((r) => r.json())
      ]);
      charset = cs;
      return ort.InferenceSession.create(model, { executionProviders: ["wasm"], graphOptimizationLevel: "all" });
    })();
    sessionPromise.catch(() => (sessionPromise = null));
  }
  return sessionPromise;
}

// Danh sách chỉ số ký tự được phép (luôn gồm 0 = blank). null = không giới hạn.
function allowedIndices(mode) {
  if (!CHARSETS[mode]) return null;
  if (allowedCache[mode]) return allowedCache[mode];
  const want = new Set(CHARSETS[mode]);
  const idx = [0];
  charset.forEach((ch, i) => { if (i > 0 && want.has(ch)) idx.push(i); });
  return (allowedCache[mode] = Int32Array.from(idx));
}

function loadImage(dataUrl) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("Không mở được ảnh captcha"));
    img.src = dataUrl;
  });
}

// Captcha dạng SVG (vd. hoadondientu): chữ là các <path> được tô (fill), đường nhiễu là nét không tô.
// Bỏ đường nhiễu + tô chữ màu đen -> đọc chính xác hơn nhiều. Ảnh không đúng dạng này thì giữ nguyên.
function cleanSvg(dataUrl) {
  try {
    const m = dataUrl.match(/^data:image\/svg\+xml(;[^,]*)?,(.*)$/s);
    if (!m) return dataUrl;
    const text = /;base64/i.test(m[1] || "")
      ? new TextDecoder().decode(Uint8Array.from(atob(m[2]), (c) => c.charCodeAt(0)))
      : decodeURIComponent(m[2]);
    const doc = new DOMParser().parseFromString(text, "image/svg+xml");
    const svg = doc.documentElement;
    if (!svg || svg.nodeName.toLowerCase() !== "svg") return dataUrl;
    const isFilled = (el) => {
      const f = (el.getAttribute("fill") || "").trim().toLowerCase();
      return f !== "" && f !== "none" && f !== "transparent";
    };
    const shapes = Array.from(svg.querySelectorAll("path, line, polyline"));
    const filled = shapes.filter((el) => el.nodeName.toLowerCase() === "path" && isFilled(el));
    const noise = shapes.filter((el) => !isFilled(el));
    if (filled.length < 3 || !noise.length) return dataUrl; // không giống kiểu captcha này
    noise.forEach((el) => el.remove());
    filled.forEach((el) => el.setAttribute("fill", "#000"));
    const out = new XMLSerializer().serializeToString(svg);
    return "data:image/svg+xml;charset=utf-8," + encodeURIComponent(out);
  } catch (e) {
    return dataUrl;
  }
}

async function toTensor(dataUrl) {
  const img = await loadImage(cleanSvg(dataUrl));
  const w0 = img.naturalWidth || img.width;
  const h0 = img.naturalHeight || img.height;
  if (!w0 || !h0) throw new Error("Ảnh captcha rỗng");
  const H = 64;
  const W = Math.max(1, Math.floor(w0 * (H / h0)));

  const canvas = document.createElement("canvas");
  canvas.width = W;
  canvas.height = H;
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  ctx.fillStyle = "#fff"; // nền trắng cho ảnh trong suốt (PNG/SVG)
  ctx.fillRect(0, 0, W, H);
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";
  ctx.drawImage(img, 0, 0, W, H);

  const px = ctx.getImageData(0, 0, W, H).data;
  const data = new Float32Array(W * H);
  const grayImg = new Uint8Array(W * H);
  for (let i = 0, j = 0; j < data.length; i += 4, j++) {
    const gray = (px[i] * 299 + px[i + 1] * 587 + px[i + 2] * 114) / 1000; // như PIL convert('L')
    grayImg[j] = gray;
    data[j] = (gray / 255 - 0.5) / 0.5;
  }
  return { tensor: new ort.Tensor("float32", data, [1, 1, H, W]), gray: grayImg, W, H };
}

// ------------------------------------------------------------ Tự nhận chữ hoa / thường
// Chữ thường của nhóm này chỉ cao bằng "x-height" (~2/3 chữ hoa); các chữ/số còn lại cao gần bằng chữ hoa.
const XHEIGHT = new Set("acemnorsuvwxz");
const DESC = new Set("gjpqy");

function otsu(gray) {
  const hist = new Array(256).fill(0);
  for (let i = 0; i < gray.length; i++) hist[gray[i]]++;
  let sum = 0;
  for (let i = 0; i < 256; i++) sum += i * hist[i];
  let sumB = 0, wB = 0, best = 0, th = 128;
  for (let t = 0; t < 256; t++) {
    wB += hist[t];
    if (!wB) continue;
    const wF = gray.length - wB;
    if (!wF) break;
    sumB += t * hist[t];
    const mB = sumB / wB, mF = (sum - sumB) / wF;
    const between = wB * wF * (mB - mF) * (mB - mF);
    if (between > best) { best = between; th = t; }
  }
  return th;
}

function median(a) {
  const s = a.slice().sort((x, y) => x - y);
  return s.length ? s[Math.floor(s.length / 2)] : 0;
}

// chars: [{ ch, t0, t1 }] - vị trí theo bước thời gian CTC. Trả về chuỗi đã sửa hoa/thường, hoặc null nếu không chắc.
function autoCase(chars, img, T) {
  const { gray, W, H } = img;
  if (chars.length < 2 || !chars.some((c) => /[a-z]/i.test(c.ch))) return null;
  const th = otsu(gray);
  let inkCount = 0;
  for (let i = 0; i < gray.length; i++) if (gray[i] < th) inkCount++;
  const dark = inkCount <= gray.length / 2; // chữ tối trên nền sáng (thường gặp)
  const isInk = (g) => (dark ? g < th : g >= th);

  const scale = W / T;
  const centers = chars.map((c) => ((c.t0 + c.t1 + 1) / 2) * scale);
  const heights = chars.map((c, i) => {
    const gapL = i > 0 ? centers[i] - centers[i - 1] : (centers[1] - centers[0]);
    const gapR = i < chars.length - 1 ? centers[i + 1] - centers[i] : gapL;
    const x0 = Math.max(0, Math.round(centers[i] - gapL * 0.45));
    const x1 = Math.min(W, Math.round(centers[i] + gapR * 0.45));
    const minInk = Math.max(2, (x1 - x0) * 0.15); // bỏ qua đường nhiễu mảnh
    let top = -1, bottom = -1;
    for (let y = 0; y < H; y++) {
      let n = 0;
      for (let x = x0; x < x1; x++) if (isInk(gray[y * W + x])) n++;
      if (n >= minInk) { if (top < 0) top = y; bottom = y; }
    }
    return top < 0 ? 0 : bottom - top + 1;
  });

  // Chiều cao chuẩn = chữ số và các chữ không thuộc nhóm x-height (luôn cao gần bằng chữ hoa).
  // Bỏ chữ có đuôi dưới (g j p q y): đuôi hay bị cắt ở mép ảnh nên đo không chuẩn.
  const ref = median(chars.map((c, i) => (XHEIGHT.has(c.ch.toLowerCase()) || DESC.has(c.ch) ? 0 : heights[i])).filter((h) => h > 0));
  if (!ref) return null; // toàn chữ nhóm x-height: không có mốc so sánh -> giữ nguyên

  // Tỉ lệ chiều cao của từng chữ nhóm x-height so với chiều cao chuẩn
  const ratios = chars.map((c, i) => (XHEIGHT.has(c.ch.toLowerCase()) && heights[i] ? heights[i] / ref : null));
  const rs = ratios.filter((r) => r != null);
  if (!rs.length) return null;
  const mean = rs.reduce((a, b) => a + b, 0) / rs.length;
  const min = Math.min(...rs), max = Math.max(...rs);
  const text = chars.map((c) => c.ch).join("");
  // Cả nhóm (>= 2 chữ) đều cao bằng chữ hoa -> captcha toàn chữ HOA
  if (rs.length >= 2 && mean >= 0.85 && min >= 0.78) return text.toUpperCase();
  // Cả nhóm đều thấp rõ -> chúng là chữ thường (chữ khác giữ như AI đọc)
  if (mean <= 0.75 && max <= 0.82) return chars.map((c) => (XHEIGHT.has(c.ch.toLowerCase()) ? c.ch.toLowerCase() : c.ch)).join("");
  // Chỉ 1 chữ, hoặc cao thấp lẫn lộn rõ ràng (captcha trộn hoa/thường): sửa riêng những chữ chắc chắn
  if (rs.length === 1 || (max >= 0.9 && min <= 0.7)) {
    return chars.map((c, i) => {
      const r = ratios[i];
      if (r == null) return c.ch;
      return r >= 0.9 ? c.ch.toUpperCase() : r <= 0.7 ? c.ch.toLowerCase() : c.ch;
    }).join("");
  }
  return null; // không chắc -> giữ như AI đọc
}

async function recognize(dataUrl, mode) {
  const t0 = performance.now();
  const session = await load();
  const img = await toTensor(dataUrl);
  const out = await session.run({ input1: img.tensor }, [LOGITS]);
  const logits = out[LOGITS];
  const [T, , C] = logits.dims;
  const v = logits.data;
  const allowed = allowedIndices(mode);

  let text = "";
  let last = 0;
  const chars = []; // ký tự + đoạn thời gian CTC (để đo chiều cao từng chữ)
  for (let t = 0; t < T; t++) {
    const base = t * C;
    let best = 0;
    let bestVal = -Infinity;
    if (allowed) {
      for (let k = 0; k < allowed.length; k++) {
        const c = allowed[k];
        if (v[base + c] > bestVal) { bestVal = v[base + c]; best = c; }
      }
    } else {
      for (let c = 0; c < C; c++) {
        if (v[base + c] > bestVal) { bestVal = v[base + c]; best = c; }
      }
    }
    if (best !== last && best !== 0) { text += charset[best]; chars.push({ ch: charset[best], t0: t, t1: t }); }
    else if (best === last && best !== 0 && chars.length) chars[chars.length - 1].t1 = t;
    last = best;
  }
  let auto = null;
  try { auto = autoCase(chars, img, T); } catch (e) { auto = null; }
  return { text, auto, ms: Math.round(performance.now() - t0) };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.target !== "offscreen") return;
  if (msg.type === "OCR") {
    recognize(msg.dataUrl, msg.charset)
      .then((r) => sendResponse({ ok: true, text: r.text, auto: r.auto, ms: r.ms }))
      .catch((e) => sendResponse({ ok: false, error: String(e && e.message ? e.message : e) }));
    return true;
  }
});
