const CONFIG = self.CAPTCHA_LOCAL_CONFIG;
const DEFAULTS = { enabled: true, charset: "alnum", letterCase: "keep" };
const $ = (id) => document.getElementById(id);

// ------------------------------------------------------------ Thông tin chung
$("ver").textContent = "v" + chrome.runtime.getManifest().version;
$("author").textContent = CONFIG.author;
$("phone").textContent = CONFIG.phone;
$("phone").href = CONFIG.zalo;

// ------------------------------------------------------------ Bản quyền
function fmtDate(ts) { return new Date(ts).toLocaleDateString("vi-VN"); }

function renderLicense(lic) {
  if (!lic) return;
  $("licId").textContent = lic.id;
  const pill = $("licPill");
  const names = { trial: "Dùng thử", licensed: "Bản quyền", expired: "Hết hạn", locked: "Đã khóa", offline: "Mất kết nối" };
  pill.textContent = names[lic.status] || lic.status;
  pill.className = "pill " + (lic.status === "trial" ? "trial" : lic.status === "licensed" ? "licensed" : "bad");
  const days = $("licDays");
  days.replaceChildren();
  if (lic.usable) {
    const b = document.createElement("b");
    b.textContent = lic.daysLeft + " ngày";
    days.append("Còn ", b, " · đến " + fmtDate(lic.until));
  } else if (lic.status === "expired") {
    days.textContent = lic.wasLicensed ? "Hết thời hạn sử dụng" : "Hết " + lic.trialDays + " ngày dùng thử";
  }
  const trial = lic.status === "trial";
  $("licBar").hidden = !trial;
  if (trial) $("licBarFill").style.width = Math.max(4, Math.min(100, (lic.daysLeft / lic.trialDays) * 100)) + "%";
  $("licAlert").hidden = lic.usable;
  $("licAlert").textContent = lic.message || "";
  $("licActions").hidden = lic.usable;
  // Ô nhập key: hiện khi chưa có bản quyền (đang dùng thử hoặc hết hạn) và đã cấu hình máy chủ
  $("keyForm").hidden = !lic.server || lic.status === "licensed" || lic.status === "locked";
  $("licHint").hidden = !lic.pending || lic.status === "licensed";
}

$("keyForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const key = $("keyInput").value.trim();
  if (!key) { $("keyInput").focus(); return; }
  $("keyBtn").disabled = true;
  $("msg").textContent = "Đang kích hoạt...";
  const r = await chrome.runtime.sendMessage({ type: "ACTIVATE", key }).catch((err) => ({ ok: false, error: String(err) }));
  $("keyBtn").disabled = false;
  if (!r || !r.ok) { $("msg").textContent = (r && r.error) || "Không kích hoạt được."; return; }
  renderLicense(r.lic);
  $("keyInput").value = "";
  $("msg").textContent = r.lic.status === "licensed"
    ? "Kích hoạt thành công! Dùng được " + r.lic.daysLeft + " ngày." : "Chưa kích hoạt được.";
});

$("licZalo").href = CONFIG.zalo;
$("licZalo").textContent = "Zalo " + CONFIG.phone;
chrome.storage.local.get("lic", ({ lic }) => renderLicense(lic));
chrome.runtime.sendMessage({ type: "LICENSE" }).then((r) => r && r.ok && renderLicense(r.lic)).catch(() => {});

$("copyId").addEventListener("click", async () => {
  await navigator.clipboard.writeText($("licId").textContent);
  $("msg").textContent = "Đã sao chép ID máy - gửi ID này qua Zalo " + CONFIG.phone + " để kích hoạt.";
});

$("licRecheck").addEventListener("click", async () => {
  $("licRecheck").disabled = true;
  $("msg").textContent = "Đang kiểm tra bản quyền...";
  const r = await chrome.runtime.sendMessage({ type: "LICENSE", force: true }).catch((e) => ({ ok: false, error: String(e) }));
  $("licRecheck").disabled = false;
  if (!r || !r.ok) { $("msg").textContent = (r && r.error) || "Không kiểm tra được."; return; }
  renderLicense(r.lic);
  $("msg").textContent = r.lic.error ? "Không kết nối được máy chủ: " + r.lic.error
    : r.lic.usable ? "Đã kích hoạt - dùng được rồi!" : "Chưa được gia hạn.";
});

// ------------------------------------------------------------ Cài đặt
function renderStatus(on) {
  $("statusTitle").textContent = on ? "Đang bật" : "Đang tắt";
  $("statusSub").textContent = on ? "Tự đọc & điền captcha" : "Bấm công tắc để bật lại";
}

chrome.storage.sync.get(DEFAULTS, (s) => {
  $("enabled").checked = s.enabled;
  renderStatus(s.enabled);
  for (const key of ["charset", "letterCase"]) {
    const el = document.querySelector(`input[name="${key}"][value="${s[key]}"]`);
    if (el) el.checked = true;
  }
});

$("enabled").addEventListener("change", (e) => {
  chrome.storage.sync.set({ enabled: e.target.checked });
  renderStatus(e.target.checked);
});
for (const key of ["charset", "letterCase"]) {
  $(key).addEventListener("change", (e) => chrome.storage.sync.set({ [key]: e.target.value }));
}

// Bật / tắt riêng cho trang đang mở
(async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  let host = "";
  try { const u = new URL(tab.url); if (/^https?:$/.test(u.protocol)) host = u.hostname; } catch (e) {}
  if (!host) return;
  $("siteHost").textContent = host;
  $("siteRow").hidden = false;
  const { disabledSites } = await chrome.storage.sync.get({ disabledSites: [] });
  $("siteOn").checked = !disabledSites.includes(host);
  $("siteOn").addEventListener("change", async (e) => {
    const cur = (await chrome.storage.sync.get({ disabledSites: [] })).disabledSites.filter((h) => h !== host);
    if (!e.target.checked) cur.push(host);
    await chrome.storage.sync.set({ disabledSites: cur });
  });

  // Chữ hoa/thường riêng cho trang này (nhớ mãi)
  const isTaxSite = /(^|\.)gdt\.gov\.vn$/i.test(host);
  const { siteCase = {} } = await chrome.storage.sync.get("siteCase");
  $("siteCaseRow").hidden = false;
  $("siteCase").value = siteCase[host] || "";
  $("siteCaseHint").hidden = !isTaxSite || !!siteCase[host];
  $("siteCase").addEventListener("change", async (e) => {
    const cur = (await chrome.storage.sync.get("siteCase")).siteCase || {};
    if (e.target.value) cur[host] = e.target.value; else delete cur[host];
    await chrome.storage.sync.set({ siteCase: cur });
    $("siteCaseHint").hidden = !isTaxSite || !!e.target.value;
    $("msg").textContent = "Đã lưu cho " + host + ". Bấm \"Đọc lại captcha\" để áp dụng.";
  });
})();

// ------------------------------------------------------------ Kết quả gần nhất
function timeAgo(ts) {
  const s = Math.round((Date.now() - ts) / 1000);
  if (s < 60) return "vừa xong";
  if (s < 3600) return Math.floor(s / 60) + " phút trước";
  if (s < 86400) return Math.floor(s / 3600) + " giờ trước";
  return new Date(ts).toLocaleDateString("vi-VN");
}

function renderLast() {
  chrome.storage.local.get(["last", "count"], ({ last, count }) => {
    $("count").textContent = (count || 0).toLocaleString("vi-VN");
    const code = $("code");
    if (!last) return;
    code.textContent = last.text;
    code.classList.remove("empty");
    code.title = last.text;
    $("copy").hidden = false;
    const meta = $("meta");
    meta.replaceChildren();
    for (const t of [timeAgo(last.at), last.ms + " ms", last.host].filter(Boolean)) {
      const span = document.createElement("span");
      span.textContent = t;
      meta.append(span);
    }
  });
}
renderLast();

$("copy").addEventListener("click", async () => {
  await navigator.clipboard.writeText($("code").textContent);
  $("copy").title = "Đã sao chép";
  $("msg").textContent = "Đã sao chép mã vào clipboard.";
});

// ------------------------------------------------------------ Đọc lại
$("rescan").addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  $("msg").textContent = await rescanTab(tab.id);
});

async function rescanTab(tabId) {
  let res;
  try {
    res = await chrome.tabs.sendMessage(tabId, { type: "RESCAN" });
  } catch (e) {
    // Trang mở từ trước khi cài/tải lại tiện ích: chèn script rồi thử lại
    try {
      await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, files: ["content.js"] });
      res = await chrome.tabs.sendMessage(tabId, { type: "RESCAN" });
    } catch (e2) {
      return "Trình duyệt không cho tiện ích chạy trên trang này (trang hệ thống, Web Store, hoặc file PDF).";
    }
  }
  if (!res || !res.found) return "Không tìm thấy ô captcha trên trang này.";
  const { lic } = await chrome.storage.local.get("lic");
  return lic && !lic.usable ? lic.message : "Đang đọc captcha...";
}

// ------------------------------------------------------------ Cập nhật
function renderUpdate(u) {
  const box = $("update");
  if (!u || !u.available) { box.classList.remove("show"); return; }
  $("updTitle").textContent = "Có bản mới v" + u.latest + " (đang dùng v" + chrome.runtime.getManifest().version + ")";
  $("updNotes").textContent = u.notes || "";
  $("updBtn").onclick = () => u.download && chrome.tabs.create({ url: u.download });
  box.classList.add("show");
}
chrome.storage.local.get("update", ({ update }) => renderUpdate(update));

$("checkUpd").addEventListener("click", async () => {
  $("msg").textContent = "Đang kiểm tra cập nhật...";
  const res = await chrome.runtime.sendMessage({ type: "CHECK_UPDATE" });
  if (!res || !res.ok) { $("msg").textContent = (res && res.error) || "Không kiểm tra được cập nhật."; return; }
  renderUpdate(res.update);
  $("msg").textContent = res.update.available ? "Đã có phiên bản mới!" : "Bạn đang dùng bản mới nhất (v" + res.update.current + ").";
});

chrome.storage.onChanged.addListener((ch, area) => {
  if (area !== "local") return;
  if (ch.last || ch.count) renderLast();
  if (ch.update) renderUpdate(ch.update.newValue);
  if (ch.lic) renderLicense(ch.lic.newValue);
});
