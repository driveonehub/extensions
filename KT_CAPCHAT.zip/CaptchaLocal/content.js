// Tìm ô nhập captcha + ảnh captcha trên trang, nhờ bộ đọc cục bộ đọc, rồi tự điền.
// Không đọc / gửi mật khẩu hay bất kỳ dữ liệu nào khác trên trang.
(() => {
  // Chỉ chạy 1 bản. Nếu bản cũ còn sót lại sau khi tiện ích được tải lại/cập nhật
  // (chrome.runtime.id đã mất) thì dừng bản cũ và chạy bản mới.
  const prev = window.__captchaLocal;
  if (prev && prev.alive()) return;
  if (prev) try { prev.stop(); } catch (e) {}
  const self = { alive: () => !!(chrome.runtime && chrome.runtime.id), stop: () => {} };
  window.__captchaLocal = self;

  // Gợi ý "mạnh": chắc chắn là ô captcha. Gợi ý "yếu": có thể là captcha, cũng có thể là OTP/xác nhận khác.
  const STRONG_HINT = /captcha|capcha|cvalue|kaptcha|checkcode|validatecode|validcode|vcode|imgcode|imagecode|securitycode|seccode|yzm|verifycode|verify_code|authcode/i;
  const WEAK_HINT = /verif|xac.?nhan|xác.?nhận|xac.?thuc|xác.?thực|kiem.?tra|kiểm.?tra|bao.?mat|bảo.?mật|security.?code|ma.?xn|mã.?xn|ma.?bao.?ve|mã.?bảo.?vệ/i;
  const INPUT_EXCLUDE = /user|login|pass|mst|tax|phone|email|search|tim.?kiem|tìm.?kiếm|otp|sms|zip|postal/i;
  const IMG_HINT = /captcha|capcha|kaptcha|cvalue|verif|imagecode|imgcode|checkcode|validatecode|validcode|securitycode|seccode|jcaptcha|servlet|random|getcode|vcode|yzm|authcode/i;
  // Trang quen thuộc: cho phép nhận diện "thoáng" hơn
  const TRUSTED = /(^|\.)(gdt\.gov\.vn|baohiemxahoi\.gov\.vn|dichvucong\.gov\.vn)$/i.test(location.hostname);

  let enabled = true;
  let siteOff = false;
  const state = new WeakMap(); // input -> { sig, filled, busy }

  let blocked = false; // hết hạn dùng thử / bản quyền -> ngừng đọc cho tới khi được gia hạn
  let noticeShown = false;
  function active() { return enabled && !siteOff && !blocked; }

  // Thông báo hết hạn (1 lần mỗi trang), dùng Shadow DOM để không bị CSS của trang làm vỡ
  function showNotice(text) {
    if (noticeShown || window.top !== window) return; // chỉ hiện ở khung chính
    noticeShown = true;
    const host = document.createElement("div");
    host.style.cssText = "all:initial;position:fixed;z-index:2147483647;right:16px;bottom:16px;";
    const root = host.attachShadow({ mode: "closed" });
    const box = document.createElement("div");
    box.style.cssText = "max-width:340px;font:13px/1.45 'Segoe UI',system-ui,sans-serif;color:#fff;background:#1f3428;" +
      "border:1px solid #4ade80;border-radius:12px;padding:12px 34px 12px 14px;box-shadow:0 8px 24px rgba(0,0,0,.3);position:relative;";
    const title = document.createElement("div");
    title.style.cssText = "font-weight:700;color:#4ade80;margin-bottom:3px;";
    title.textContent = "KT_AI Captcha";
    const body = document.createElement("div");
    body.textContent = text;
    const close = document.createElement("button");
    close.textContent = "×";
    close.style.cssText = "position:absolute;right:8px;top:6px;background:none;border:0;color:#fff;font-size:18px;cursor:pointer;";
    close.onclick = () => host.remove();
    box.append(title, body, close);
    root.append(box);
    (document.body || document.documentElement).append(host);
    setTimeout(() => host.remove(), 15000);
  }

  chrome.storage.onChanged.addListener((ch, area) => {
    if (area === "local" && ch.lic && ch.lic.newValue && ch.lic.newValue.usable && blocked) {
      blocked = false; // vừa được gia hạn
      noticeShown = false;
      schedule();
    }
  });

  chrome.storage.sync.get({ enabled: true, disabledSites: [] }, (s) => {
    enabled = s.enabled;
    siteOff = s.disabledSites.includes(location.hostname);
    if (active()) schedule();
  });
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area !== "sync") return;
    if (ch.enabled) enabled = ch.enabled.newValue;
    if (ch.disabledSites) siteOff = (ch.disabledSites.newValue || []).includes(location.hostname);
    if (active()) schedule();
  });

  // ------------------------------------------------------------ tiện ích DOM
  function visible(el) {
    if (!el || !el.isConnected) return false;
    const r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    const cs = getComputedStyle(el);
    return cs.visibility !== "hidden" && cs.display !== "none" && Number(cs.opacity) > 0.05;
  }

  function attrText(el) {
    return [el.id, el.name, el.className && el.className.baseVal !== undefined ? el.className.baseVal : el.className,
      el.getAttribute("placeholder"), el.getAttribute("aria-label"), el.getAttribute("formcontrolname"),
      el.getAttribute("alt"), el.getAttribute("title"), el.getAttribute("ng-model"), el.getAttribute("data-testid")]
      .filter(Boolean).join(" ");
  }

  function labelText(input) {
    let t = "";
    if (input.id) {
      const lb = document.querySelector('label[for="' + CSS.escape(input.id) + '"]');
      if (lb) t += " " + lb.textContent;
    }
    const wrap = input.closest("label");
    if (wrap) t += " " + wrap.textContent;
    return t;
  }

  // Trả về "strong" | "weak" | null
  function captchaInputKind(el) {
    if (el.disabled || el.readOnly) return null;
    const type = (el.getAttribute("type") || "text").toLowerCase();
    if (!["text", "tel", "search", "number", ""].includes(type)) return null;
    if (el.getAttribute("autocomplete") === "one-time-code") return null; // ô OTP
    const a = attrText(el);
    if (STRONG_HINT.test(a)) return "strong";
    if (INPUT_EXCLUDE.test(a)) return null;
    if (WEAK_HINT.test(a) || WEAK_HINT.test(labelText(el))) return "weak";
    if (STRONG_HINT.test(labelText(el))) return "strong";
    return null;
  }

  function imageLike(el) {
    const tag = el.tagName.toLowerCase();
    if (!["img", "canvas", "svg"].includes(tag) || !visible(el)) return false;
    const r = el.getBoundingClientRect();
    return r.width >= 40 && r.width <= 450 && r.height >= 15 && r.height <= 160;
  }

  function imgScore(el) {
    let s = 0;
    const src = el.tagName.toLowerCase() === "img" ? (el.getAttribute("src") || "") : "";
    if (IMG_HINT.test(attrText(el))) s += 3;
    if (src && !src.startsWith("data:") && IMG_HINT.test(src)) s += 3;
    if (src.startsWith("data:image/svg") || src.startsWith("data:image/png") || src.startsWith("data:image/jp")) s += 1;
    return s;
  }

  // Tìm ảnh captcha gần ô nhập: đi lên tối đa 8 cấp cha, lấy ảnh phù hợp nhất & gần nhất.
  // Từ cấp thứ 6 trở đi (form chia cột như hoadondientu) chỉ nhận ảnh trông giống captcha.
  function findImageFor(input) {
    const ir = input.getBoundingClientRect();
    let node = input.parentElement;
    for (let depth = 0; node && depth < 8; depth++, node = node.parentElement) {
      if (node === document.body || node === document.documentElement) break;
      // imageLike() đã loại các biểu tượng nhỏ (nút làm mới, logo...) theo kích thước
      let cands = Array.from(node.querySelectorAll("img, canvas, svg")).filter(imageLike);
      if (depth >= 5) cands = cands.filter((c) => imgScore(c) > 0);
      if (!cands.length) continue;
      cands.sort((a, b) => {
        const d = imgScore(b) - imgScore(a);
        if (d) return d;
        const ra = a.getBoundingClientRect(), rb = b.getBoundingClientRect();
        return Math.hypot(ra.x - ir.x, ra.y - ir.y) - Math.hypot(rb.x - ir.x, rb.y - ir.y);
      });
      return cands[0];
    }
    return null;
  }

  // ------------------------------------------------------------ lấy ảnh
  function signature(el) {
    const tag = el.tagName.toLowerCase();
    if (tag === "img") return "img:" + (el.currentSrc || el.src || "");
    if (tag === "svg") { const h = el.innerHTML; return "svg:" + h.length + ":" + h.slice(0, 200) + h.slice(-200); }
    try { const d = el.toDataURL(); return "cv:" + d.length + ":" + d.slice(-200); } catch (e) { return "cv:?"; }
  }

  async function imagePayload(el) {
    const tag = el.tagName.toLowerCase();
    if (tag === "svg") {
      const svg = el.cloneNode(true);
      if (!svg.getAttribute("xmlns")) svg.setAttribute("xmlns", "http://www.w3.org/2000/svg");
      const r = el.getBoundingClientRect();
      if (!svg.getAttribute("width")) svg.setAttribute("width", Math.round(r.width));
      if (!svg.getAttribute("height")) svg.setAttribute("height", Math.round(r.height));
      return { dataUrl: "data:image/svg+xml;charset=utf-8," + encodeURIComponent(new XMLSerializer().serializeToString(svg)) };
    }
    if (tag === "canvas") return { dataUrl: el.toDataURL("image/png") };

    // <img>
    const src = el.currentSrc || el.src || "";
    if (src.startsWith("data:")) return { dataUrl: src };
    if (!el.complete || !el.naturalWidth) {
      await new Promise((res) => { el.addEventListener("load", res, { once: true }); setTimeout(res, 3000); });
    }
    try {
      // Vẽ lại ảnh đang hiển thị (không tải lại -> không làm đổi mã captcha)
      const c = document.createElement("canvas");
      c.width = el.naturalWidth;
      c.height = el.naturalHeight;
      c.getContext("2d").drawImage(el, 0, 0);
      return { dataUrl: c.toDataURL("image/png") };
    } catch (e) {
      // Ảnh khác nguồn: nhờ service worker tải lại (một số trang sẽ sinh mã mới khi tải lại)
      return { url: src };
    }
  }

  // ------------------------------------------------------------ điền kết quả
  function setValue(input, value) {
    const proto = Object.getPrototypeOf(input);
    const desc = Object.getOwnPropertyDescriptor(proto, "value") || Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value");
    desc.set.call(input, value);
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
  }

  function flash(input, ok) {
    const old = input.style.outline;
    input.style.outline = ok ? "2px solid #16a34a" : "2px solid #dc2626";
    setTimeout(() => (input.style.outline = old), 1200);
  }

  async function solve(input, img, force) {
    if (!self.alive()) return self.stop(); // bản cũ sau khi tiện ích được tải lại
    const st = state.get(input) || {};
    state.set(input, st);
    const sig = signature(img);
    if (st.busy) return;
    if (!force && st.sig === sig) return;
    // Người dùng đã tự gõ thì không ghi đè (trừ khi bấm "Đọc lại").
    // Giá trị do tiện ích điền được đánh dấu trên ô nhập để bản chạy sau khi tải lại tiện ích vẫn nhận ra.
    if (!force && input.value && input.value !== input.dataset.captchaLocalFilled) return;

    st.busy = true;
    try {
      const payload = await imagePayload(img);
      const res = await chrome.runtime.sendMessage(Object.assign({ type: "OCR" }, payload));
      st.sig = signature(img) === sig ? sig : null; // ảnh đã đổi trong lúc đọc -> đọc lại lần sau
      if (res && res.ok && res.text) {
        if (st.sig) {
          input.dataset.captchaLocalFilled = res.text;
          setValue(input, res.text);
          flash(input, true);
        }
      } else if (res && res.code === "LICENSE") {
        blocked = true;
        st.sig = null;
        showNotice(res.error);
        return;
      } else {
        flash(input, false);
        console.warn("[KT_AI Captcha]", res && res.error);
      }
    } catch (e) {
      console.warn("[KT_AI Captcha]", e);
    } finally {
      st.busy = false;
    }
    if (!st.sig) schedule();
  }

  const boundImgs = new WeakSet(); // theo từng bản chạy (không dùng cờ trên DOM vì bản cũ có thể đã đặt)
  function bindRefresh(input, img) {
    if (boundImgs.has(img)) return;
    boundImgs.add(img);
    if (img.tagName.toLowerCase() === "img") img.addEventListener("load", () => solve(input, img, false));
  }

  function scan(force) {
    if (!active() && !force) return 0;
    let found = 0;
    for (const input of document.querySelectorAll("input")) {
      const kind = captchaInputKind(input);
      if (!kind || !visible(input)) continue;
      const img = findImageFor(input);
      if (!img) continue;
      // Ngoài các trang quen thuộc, gợi ý "yếu" cần thêm ảnh trông giống captcha
      if (kind === "weak" && !TRUSTED && !force && imgScore(img) < 1) continue;
      found++;
      bindRefresh(input, img);
      if (force) state.delete(input);
      solve(input, img, force);
    }
    return found;
  }

  let timer = null;
  function schedule() {
    clearTimeout(timer);
    timer = setTimeout(() => scan(false), 300);
  }

  const observer = new MutationObserver(() => {
    if (!self.alive()) { self.stop(); return; } // tiện ích đã bị tải lại -> bản này ngừng
    if (active()) schedule();
  });
  observer.observe(document.documentElement, {
    subtree: true, childList: true, attributes: true, attributeFilter: ["src", "style", "class"]
  });
  self.stop = () => { observer.disconnect(); clearTimeout(timer); enabled = false; };
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === "RESCAN") { noticeShown = false; sendResponse({ found: scan(true) || 0 }); }
  });
})();
