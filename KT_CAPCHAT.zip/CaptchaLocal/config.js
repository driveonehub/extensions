// Cấu hình chung (dùng cho cả service worker và popup).
// apiUrl: địa chỉ Ứng dụng web Google Apps Script (kết thúc bằng /exec) - dùng cho bản quyền + cập nhật.
//         Để trống = chỉ dùng thử 14 ngày, không kích hoạt được, không kiểm tra cập nhật.
self.CAPTCHA_LOCAL_CONFIG = {
  author: "LỀNH SẦU",
  phone: "0908900053",
  zalo: "https://zalo.me/0908900053",
  apiUrl: "https://script.google.com/macros/s/AKfycbxYt-h0K6OeBYyo9yP8FIGOPESYxFLIp2UrYH2zvJJEVMt7uFtC1ONZwKYeybBfBRn2bQ/exec",
  // Khóa công khai để kiểm tra chữ ký của máy chủ (cặp với PRIVATE_KEY trong server/Code.gs)
  publicKey: "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEArNJSJRPv0lr3cFzF36MDXC0cT65+9ZfekExm5xk+RL9BRfQ25YSbtRofpKyKp/QTzqjto5ziqZ5Qg0FV7MWbJTMbxDaPdJC+Aa+8RxdN3GmY7+0TiNvh3MYjNBs+Ze8st8eTBmHmgfzbw0PTDc2zGACs+jVMnhQPF50nn+EuHeyrtRJKPfqkWDgEbo79RB1LGMprySfPp44cJnA9FY8OQlwTXBKYKKJeiNg1+32SWRBEXT3JHGjMUWfebpbY8ePm0GreFKrBUvpnH8DKLaKeV1XMaYn4kiOlm4b7zxKuHMR++4L0c4mM9nBQ7guMUCP/5GZLaQhNb7/0wBycJluu9wIDAQAB",
  trialDays: 14,
  checkEveryHours: 6,
  offlineGraceDays: 7 // bản quyền vẫn chạy tối đa ngần này ngày nếu không kết nối được máy chủ
};
